﻿namespace WebApp.Models
{
    public class Laptop
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string ModelName { get; set; }

    }
}
